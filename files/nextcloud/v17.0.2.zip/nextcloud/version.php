<?php 
$OC_Version = array(17,0,2,1);
$OC_VersionString = '17.0.2';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '16.0' => true,
    '17.0' => true,
  ),
  'owncloud' => 
  array (
  ),
);
$OC_Build = '2019-12-19T08:48:51+00:00 8306acc940c0c8d4c0c3798b742d6ca8be3fcff0';
$vendor = 'nextcloud';
